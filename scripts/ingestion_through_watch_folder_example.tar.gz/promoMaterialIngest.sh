#!/bin/bash

CONTENT_DIRECTORY=$1
CONTENT_FILENAME=$2
TAG_NAME=$3

urlencode() {
    # urlencode <string>

    local length="${#1}"
    for (( i = 0; i < length; i++ )); do
        local c="${1:i:1}"
        case $c in
            [a-zA-Z0-9.~_-:/]) printf "$c" ;;
            *) printf '%%%x' \'"$c" ;;
        esac
    done
}

CONTENT_PATHNAME=$(urlencode "$CONTENT_DIRECTORY$CONTENT_FILENAME")

#echo $CONTENT_PATHNAME >> /tmp/incron.txt

curl -k --include -X GET "https://mms-gui.rsi.ch/catramms/rest/api_rsi_v1/materialPromo/$TAG_NAME?ContentPathName=$CONTENT_PATHNAME"

